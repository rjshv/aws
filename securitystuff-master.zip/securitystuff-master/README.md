Inefficient code by SnoozeSecurity (youtube.com/channel/UCa5QaVWjwFkUNoLtMka1d3w)

Mainly scripts for CTF-related activities, here to learn more
